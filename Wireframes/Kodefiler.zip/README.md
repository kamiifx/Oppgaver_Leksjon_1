## For å kjøre prosjektet kan du (for å bruke linting etc)

- cd inn i mappen 02_js der package.json filen ligger
- npm install
- (krever at eslint er installert +++, noe vi lærer om i forelesning 3)

## Hvis du ikke installerer noe så kan du godt slette:

- slette .eslintingore
- slette .eslintrc.json
- slette package.json
- slette node_modules (hvis du installerte noe)
- slette .vscode mappen som har extensions.json og settings.json filen)

## Og deretter bare bruke filene

Bare bruke filene direkte der du måtte ønske ved å kopiere ut filen i egen mappe
