/**
 *
 * Browser spesifikke funksjoner. Noen av metoden er rettet mode "nodene", mens andre mot elementet
 *
 */

// let element = document.querySelector("element");
// let elements = document.querySelectorAll("element");
// let attr = element.hasAttribute("attr");
// let style = (element.style.width = "value");
// let nodeName = element.nodeName;
// let children = element.children;
// let placeElement = element.insertAdjacentElement(position, element);
// let addChild = element.appendChild(element)
// let hasChildren = element.hasChildNodes();
// let traversePrev = element.previousSibling;
// let traverseNext = element.nextElementSibling;
// let addEventListener = element.addEventListener(event, f, false);
// let removeEventListener = element.removeEventListener(event, f);
// let checkForNode = element.contains(otherNode);
// let parent = element.parentElement;
// let setText = (element.innerHTML = "text");
// let getText = element.innerHTML;
// let createElement = document.createElement("a");
// let setClass = element.classList.add("class");
// let getId = document.getElementById("id");

const main = document.getElementById('container');

const p = document.createElement('p');
p.innerHTML = 'HIOF JS';
console.log(main.hasChildNodes());
main.appendChild(p);
console.log(main.hasChildNodes());

const elements = ['div', 'p', 'div'];

const createElements = () =>
  elements.map((elem) => document.createElement(elem));

const addElemementsWithText = () => {
  const el = createElements();
  el.map((e, i) => {
    e.innerHTML = `${i} text`;
    main.appendChild(e);
  });
};

addElemementsWithText();
const div = document.querySelector('div');
console.log(main.childElementCount);
console.log(main.contains(div));
console.log(div.previousSibling.tagName);
console.log(div.nextSibling.innerHTML);
div.style.border = '1px solid red';
p.classList.add('red');

const element1 = document.querySelector('.element1');

console.log(element1.children);
console.log(element1.firstElementChild);
console.log(element1.lastElementChild);
console.log(element1.previousElementSibling);
console.log(element1.nextElementSibling);
console.log(element1.parentElement);

const p2 = document.createElement('p');
p2.textContent = 'I will be removed';
document.body.appendChild(p2);

p2.remove();

console.log(p2);

document.body.appendChild(p2);
