/* eslint-disable no-var */
/**
 *
 * Closure er knyttet til scope
 * Funksjonen inne i en annen funksjon kjenner til sitt scopet hvor den "bor" og derav variablene som er i samme scope
 * Sagt på en annen måte så kjenner den indre funksjonen til det som omfavner den
 * Fordelen med closure er at man kan ha private variabler og funksjoner som ikke blir eksponert
 *
 * Kan sammenligne det med en blokk hvor den som bor i 1.etg kjenner den som bor i 4.etg. Men de utenfor kjenner ikke de som bor i kjelleren da de ikke har vindu (kan ikke se inn).
 *
 */

function outer() {
  const outerVar = "Jeg bor utenfor 'inner' og 'private' funksjonen";

  // Privat og ikke tilgjengeliggjort (ikke returnert)
  function private(privateVar) {
    console.log(privateVar);
    return function privateInner() {
      console.log(outerVar);
    };
  }

  // Tilgjengeliggjør inner funksjonen
  return function inner() {
    const innerVar = "Jeb bor inne i inner";
    console.log(innerVar);
    // Er tilgjengelig da inner kjenner til outer sitt scope
    console.log(outerVar);
    private("private");
    // Har også tilgang til outerVar da den kjenner til omkringliggende scope
    private()();
  };
}

const inner = outer(); // outer returnerer inner funksjonen. Kan også skrive outer()();
inner();


// Eksempel med public og private
function addCustomCarDesign(config) {

  // Private variabler men mutable (kan endres via private funksjoner)
  // Kan ikke settes direkte fra ytre scope
  let color = "rød";
  let doors = "5";
  let type = "stasjonsvogn";

  // Private og ikke mutable
  let engine = 'el';

  // Private
  function addColor() {
    color = config ? config.color : color;
  }

  // Private
  function setDoorCount() {
    doors = config ? config.doors : doors;
  }

  // Private
  function setType() {
    type = config ? config.type : type;
  }

  // Public
  function buildCar() {
    addColor();
    setType();
    setDoorCount();
    return `Bilen har ${color} farge, ${doors} dører og er av typen ${type}. Bilen har ${engine}-motor.`;
  }

  return buildCar;
}

const carConfig = {
  doors: 2,
  type: "sport",
  color: "blå",
};

const car = addCustomCarDesign(carConfig)();
const defaultCar = addCustomCarDesign()();
console.log(car);
console.log(defaultCar);
