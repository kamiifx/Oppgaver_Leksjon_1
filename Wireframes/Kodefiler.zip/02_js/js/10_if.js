/**
 *
 * Conditional kan gjøres på flere måter og er veldig vanlig å bruke
 *
 */

const age = 15;
const statement = age < 18;
const otherStatement = age > 18;

if (statement) {
  console.log('first statment passed...');
} else if (otherStatement) {
  console.log('second statement passed, first failed...');
} else {
  console.log('all of the others failed');
}

const food = 'fisk';
const vegtable = 'gulrot';
const juice = 'eple';

// vil kjøre da venstre er true.

if (food === 'fisk' || (vegtable === 'potet' && juice === 'appelsin')) {
  console.log('first statment passed...');
}

// Else vil kjøre da juice er forskjellig fra "appelsin"

if (food === 'fisk' && vegtable === 'gulrot' && juice === 'appelsin') {
  console.log('first statment passed...');
} else {
  console.log('second statement passed, first failed...');
}

// If med funksjon som test
function validateSomething(myAge) {
  return myAge > 15;
}

if (validateSomething(18)) {
  console.log('first statment passed...');
}

// IF med negated verdi - "hvis du ikke har penger på kontoen"

const moneyInTheBank = 0;

if (!(moneyInTheBank > 0)) {
  console.log('cancel');
} else {
  console.log('withdrawal');
}

// Ternery

const ternery1 = 2 > 3; // false
const ternery2 = 4 > 3; // true

// Logical operators

const aNumber = 42;
const aString = 'abc';
const aNull = null;

// Undersøker om uttrykket er true eller false

// && - hvis første uttrykk er true skriv ut uttrykk etter &&
console.log(!!aNumber && aString);

// || - hvis første uttrykk er true skriv ut dette, ellers skriv til uttrykket etter ||
console.log(!!aNumber || aString);
console.log(!!aNull || aString);

aNumber || aString; // 42 - gi meg venstre hvis testen er true ellers høyre
aNumber && aString; // "abc" - gi meg høyre kun hvis testen er true ellers gi meg venstre

aNull || aString; // "abc" - gi meg venstre hvis true ellers høyre
aNull && aString; // null - gi meg høyre hvis testen er true ellers gi meg venstre

function foo(a, b) {
  a = a || 'hello';
  b = b || 'world';
  console.log(`${a} ${b}`);
}

foo("That's it!", ''); // "That's it! world"

// And And eller short circute

const isAuthenticated = true;
const showPrivatePage = () => console.log('Private page');
const showPublicPage = () => console.log('Public page');

isAuthenticated && showPrivatePage(); // Private page
isAuthenticated || showPublicPage(); // Public page

// Switch

notification({ text: 'info', status: 'info' });

function notification({ text, status }) {
  switch (status) {
    case 'info':
      console.log(text);
      break;
    case 'warning':
      console.log(text);
      break;
    case 'error':
      console.log(text);
      break;
    default:
      return null;
  }
}
