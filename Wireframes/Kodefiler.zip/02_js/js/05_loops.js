/**
 *
 * Iterere over verdier
 *
 */

const baseArray = Array.from('mariuswallin');
const baseArray2 = ['1', '2', , '4'];
const plates = [
  {
    name: 'Frokost',
    foods: [
      {
        name: 'Brødskiver',
        calories: '45',
      },
      {
        name: 'Melk',
        calories: '45',
      },
      {
        name: 'Pålegg',
        calories: '45',
      },
    ],
  },
  {
    name: 'Middag',
    foods: [
      {
        name: 'Fisk',
        calories: '145',
      },
      {
        name: 'Poteter',
        calories: '245',
      },
      {
        name: 'Grønnsaker',
        calories: '45',
      },
    ],
  },
];

const obj = {
  prop1: 'value1',
  prop2: 'value2',
  prop3: 'value3',
};

// Vanlig for-loop

for (let i = 0; i < baseArray.length; i += 1) {
  console.log(baseArray[i]);
}

// ForEach
baseArray.forEach((value, index) => console.log(value, index));

// For in(gir indexen)
for (const i in plates) {
  console.log(plates[i].name);
}

// For of (gir selve verdien)
for (const [key, value] of Object.entries(obj)) {
  console.log(key, value);
}

for (const [index, value] of baseArray2.entries()) {
  console.log(index, value);
}

for (const value of baseArray2) {
  console.log(value);
}

// While
let i = 0;
while (baseArray2[i]) {
  console.log(baseArray2[i]);
  i += 1;
}
