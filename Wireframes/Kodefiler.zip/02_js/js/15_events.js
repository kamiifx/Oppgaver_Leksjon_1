/**
 *
 * Events
 *
 */

function logEvent(event) {
  console.log(event.type);
  console.log(event.currentTarget); // elementet som trigget eventet
  console.log(event.target);
  console.log(event.key);
}

const handleClick = (event) => {
  console.log(event);
  event.stopPropagation(); // stopper på elementet du klikket på istendefor å bubble opp hele domtreet (som er normal behavior)
};

const handleSubmit = (event) => {
  // forhindrer form i å bli submitted
  event.preventDefault();
};

const button = document.querySelector('button');
button.addEventListener('click', handleClick);

const form = document.querySelector('form');
form.addEventListener('submit', handleSubmit);

const input = document.querySelector('input');
input.addEventListener('keyup', logEvent);
input.addEventListener('keydown', logEvent);
input.addEventListener('focus', logEvent);
input.addEventListener('blur', logEvent);
