/**
 * Funksjoner er bærebjelken i JavaScript
 * Vi har innebygde funksjoner for komplekse primitive
 * Vi har innebygde funksjoner som er tilgjengelig i JavaScript
 *
 */

/**
 * Noen innebygde funksjoner på komplekse primitive (string og number)
 */

const string = 'STRING'.toLowerCase(); // string
const number = (2).toString(); // '2'
const bool = true.toString(); // 'true'
const fixed = (1.23).toFixed(1); // '1.2'
const charAt = 'test'.charAt(1); // e
const subString = 'word'.substring(1, 3); // or
const indexOf = 'word'.indexOf('o'); // 1
const indexOfNotFound = 'word'.indexOf('e'); // -1
const { length } = 'word'; // 4
const slice = 'word'.slice(1, -2); // o
const split = 'my word'.split(' '); // ['my', 'word']
const concat = 'word'.concat('press'); // wordpress

parseInt('1'); // 1
parseInt('word'); // NaN
parseInt('22am'); // 22
parseFloat('5.678'); // 5.678

/**
 *
 * Andre innebygde funksjoner
 *
 */

const abs = Math.abs(-1); // 1
const max = Math.max(2, 4, 5); // 5
const min = Math.min(1, 3, 4);
const floor = Math.floor(1.4); // 1
const ceil = Math.ceil(1.6); // 2
const round = Math.round(2.5); // 3
const now = Date.now(); // langt nummer (epoc)
const date = new Date();
const year = date.getFullYear(); // 2020
const day = date.getDay(); // 6
const month = date.getMonth(); // 5
const iso = date.toISOString(); // ISOSTRING
const utc = date.toUTCString(); // UTC STRING
const local = date.toLocaleDateString(); // month/day/year
const randomBetweenMaxMin = Math.floor(Math.random() * (max - min + 1)) + min;
const uri = 'https://mozilla.org/?filter=pølse';
const encoded = encodeURI(uri); // ../?filter=p%C3%B8lse
const encodedURI = encodeURIComponent('test øl'); // test%20%C3%B8L
const decode = decodeURI(encodedURI); // test øl
