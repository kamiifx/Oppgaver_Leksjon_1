/* eslint-disable no-var */
/**
 *
 * Basisen du må kjenne til
 * - Primitive verdier og basis operators
 * - Truthy og falsey
 * - Komplekse primitiver
 * - Hvordan verdier sammenlignes i JS
 *
 */

/**
 *
 * Basis operators
 *
 */

let value1 = 2; // 2
let value2 = 2 + 2; // 4
const divedeZero = 2 / 0; // Infinity
const doubleValue = 2 * 2; // 4
const decrement = value1--; // 2
const increment = value1++; // 1
const decrementBefore = --value2; // 3
const incrementBefore = ++value2; // 4
const stringNumber = `${2}2`; // '22'
const stringString = '2' + '2'; // '22' blir concatinated
const floatNumber = 1.2 + 1.2; // 1.4
const floatNumberMult = 1.2 * 1.2; // 1.44
const modules = 2 % 2; // 0
const modules2 = 7 % 3; // 1 (7 / 3 = 2 med 1 i rest)

/**
 *
 *  Eksempel på hva slags primitiver ulike verdier er
 *
 */

const values = [2, 'test', undefined, null, true, false, {}, function () {}];

function whatType() {
  for (let i = 0; i < values.length; i++) {
    console.log(typeof values[i]);
  }
}

whatType();

/**
 *
 *
 * Boolean operators og "truthy" og falsy
 *
 *
 */

const greaterThan = 7 > 3; // true
const lesserThan = 3 < 7; // true
const equalTypeAndValue = 3 === 3; // true
const equalValue = 3 == '3'; // true
const greaterOrEqual = 3 >= 3; // true
const lesserOrEqual = 3 <= 3; // true

/**
 *
 * !! konverterer verdien til en Boolean verdi
 * Greit å kjenne til hvilke verdier som faktisk er truthy og falsy
 *
 *
 */

// Falsy verdier
const eq5 = !!undefined === false; // true
const eq6 = !!null === false; // true
const eq14 = !!NaN === false; // true
const eq15 = !![].length === false; // true
const eq16 = !!{}.length === false; // true
const eq8 = !!0 === false; // true
const eq9 = !!'' === false; // true
const eq13 = !!false === false; // true

// Truthy verdier (og alle andre)
const eq7 = !!{} === true; // true
const eq10 = !!'2' === true; // true
const eq11 = !!1 === true; // true
const eq12 = !!function () {} === true; // true

// Ex: Hva skrives ut nedenfor?
const dataFromApi = {};

if (!dataFromApi) {
  console.log('No data');
} else {
  console.log('Have data'); // Have data
}

const printTemp = (temp) => {
  if (temp) {
    console.log(`Dagens temperatur er ${temp}`);
  } else {
    console.log('Ingen temperatur i dag');
  }
};

printTemp(2);
printTemp(0);

const arr = [1, 2, 3, 4];
const isInArray = (value) => {
  const index = arr.findIndex((num) => num === value);
  console.log(!index);
  if (!index) return;
  return index;
};

console.log(isInArray(1)); // undefined da index = 0 som er en falsy value

/**
 *
 * VERDIER OG REFERANSER
 *
 */

// Vi skiller mellom verdi og referansen i javascript
// Mange kjenner ikke til at vi i JavaScript har primitive verdier og komplekse primitive verdier

// Primitive verdier sammenlignes basert på verdien de har verdi (string, number, bigint, boolean, symbol, null, undefined ...)

// Komplekse primitive verdier sammenlignes basert på referanse (String, Number, Boolean, Object, Function). Det er de komplekse som har innebygde funksjoner og når du tar toString() på en primitiv blir den automagisk gjort om til et kompleks primitiv

// Primitive verdier er immutable

const string = 'myString';
const string2 = 'myString';
const string3 = string2;
string3.toUpperCase();
const string4 = string3;
const eq1 = typeof string === 'string'; // true
const eq2 = string2 === string; // true (samme verdi)
const eq3 = string3 === string2; // true (samme verdi)
const eq4 = string4 === string3; // true - primitive er immutable. Den opprinnelige verdien til string3 uendret selv om vi har gjort toUpperCase()

// Primitive sammenlignes basert på verdien de har
let a = 'test';
const b = 'test';
const c = a;

console.log(a === b); // true

// Å endre a verdien endrer ikke c verdien da de ikke peker til samme referanse
a = 'test2';

console.log(c === a); // false

const str = 'hello';
typeof str; // "string"
str instanceof String; // false da primitive string ikke er av typen String selv om den har String egenskaper når vi bruker den (kompleks primitiv)
str instanceof Object; // false da primitive string ikke er et Objekt selv om den har Object egenskaper når vi bruker den (kompleks primitiv)

const x = { name: 'Marius', age: 33 };
const y = { name: 'Marius', age: 33 };
const z = y;

console.log(typeof x, x instanceof Object); // object true => som betyr at den er en kompleks primetiv

// Verdiene er like men referansen er forskjellig
console.log(x === y); // false
// Lik referanse => peker til samme referanse
console.log(y === z); // true

y.name = 'Marius Wallin';
z.name = 'Test';
console.log(z.name, y.name); // Verdien oppdateres begge steder

// Oppdatere verdien på y.name gjør at z.name også blir oppdatert da de har samme referanse
console.log(y === z); // true

/**
 *
 *
 *
 * MER IMMUTABILITET
 *
 *
 */

const word = 'immutableWord';
word.substring(0, 3); // imm
const immutable = 'immutableWord'.substring(0, 3); // imm
const immutable2 = word.substring(0, 3); // imm
const word2 = word; // word2 = 'immutableWord' da verdien til word er uendret (immutable)

// Hvorfor må du vite dette?

let name = 'Marius Wallin';

function splitIntoFirstAndLastName() {
  name = name.split(' '); // Endrer variabelen => leder ofte til bugs
}

// Muterer og reassigner global variabel
splitIntoFirstAndLastName();

console.log(name); // ['Marius', 'Wallin'];

const baseDoNotChangeConfig = { importantSecret: 'secret' };

const updatecConfig = () => {
  baseDoNotChangeConfig.importantSecret = 'changedsecret';
};

const stopHacking = () => {
  if (baseDoNotChangeConfig.secret === 'secret') {
    console.log('Stop Hacking');
    return;
  }
  console.log('Hacking ...');
};

updatecConfig();
stopHacking();
