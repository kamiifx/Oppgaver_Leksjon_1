/**
 *
 * Functions
 *
 */

// Normal funksjon

function calc(a, b) {
  return a + b;
}

// Named Function Expression

// doSomething();
// namedFunction(); // sjekke opp den kun hjelper til errorhåndtering
const doSomething = function namedFunction(foo) {
  // do something
};

// Function Expressions (anonyme funksjoner)
const func = function () {};

const funcWithReturn = function () {
  return 'something';
};

func(); // returnerer undefinded
funcWithReturn(); // returnerer 'something'

// Slim Arrow Function
const arealSquare = (side) => side * 4;

const calcArrow = (a, b) => a + b;

function calcWithObjectReturn(a, b) {
  return {
    value1: a,
    value2: b,
    sum: a + b,
  };
}
const calcWithObjectReturnArrow = (a, b) => ({
  value1: a,
  value2: b,
  sum: a + b,
});

// IIFE Immidiate Invoked Function Expression
// Kjører med en gang javascriptet er lastet inn
// Brukes ofte når du må sette en "base" config fra starten av

let transformedConfigAfterJSLoaded;

(function (config) {
  transformedConfigAfterJSLoaded = config;
})({ name: 'Marius Wallin' });

// Funksjoner i objekter => ulike måter å skrive funksjoner på

const obj = {
  name: 'Marius Wallin',
  age: 35,
  gender: 'male',
  showAge() {
    console.log(this.age);
  },
  showGender() {
    // ES6 => mer om denne
    console.log(this.gender);
  },
  createSentence: () => {
    // ES6 => mer om denne
    console.log(this);
    console.log(`${obj.name} er ${obj.age} og av typen ${obj.gender}`);
  },
};
