/* eslint-disable no-var */
/**
 *
 * Hoisting virker på den måten at du "finner" funksjoner og variabel før de er deklaert
 * Skiller mellom variabel og funksjon deklarasjon
 * Første gang JS kjører så initialiseres alle variabler
 * Andre gange JS kjører så finner JS hva variabelen kan gjøre
 *
 */

let x;
console.log(x); // Variabelen eksisterer men verdien er ikke satt
console.log(a); // Failer da a ikke er initialsert (let gir mer trygghet)
console.log(b); // Finner variabelen men verdien er ikke satt
x = 3;
const a = 4;
var b = 3;
calc(3); // Hoista til toppen og tilgjengelig fra starten av. Bad praksis
anonymFunc(3); // Feiler da den ikke vet hva anonymFunc. Variabelen er satt men vet ikke hva den er

function calc(value) {
  const a = 'test';
  console.log(value * 2);
  return a;
}

const anonymFunc = function (value) {
  console.log(value * 2);
};
