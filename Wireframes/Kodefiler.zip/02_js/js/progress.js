const wrapper = document.getElementById('wrapper');
const body = document.querySelector('body');
const sentence = 'Lærer å bruke JavaScript på HIOF';
const myList = sentence.split(' ');
const types = ['p', 'div', 'li'];
const style =
  'display: flex; justify-content: center; align-items: center; width: 500px; margin: 10px auto; list-style: none; border: 1px solid #ccc; height: 50px; box-sizing: border-box;';

let current = 0;
let currentChild = 0;

const resetWrapperStyle = () => {
  wrapper.style.padding = 0;
};

const addText = (el, text) => {
  el.innerHTML = text;
  return el;
};

const addElement = (node, el) => {
  node.appendChild(el);
};

const setError = (msg) => {
  wrapper.innerHTML = msg;
};

const createElement = (type) => {
  if (!types.includes(type))
    throw new Error(`Kan kun lage elementer at typen ${types.join(', ')}`);
  return document.createElement(type);
};

const createListElements = () => {
  myList.map((text) => addElement(wrapper, addText(createElement('li'), text)));
};

const getListElements = () => [...document.querySelectorAll('li')];

const setStyle = () => {
  const liElements = getListElements();
  liElements.map((li) => (li.style.cssText = style));
};

const createNextButton = () => {
  const btn = document.createElement('button');
  btn.textContent = 'Next';
  btn.style.cssText =
    'width: 500px; margin: 0 auto; display: block; padding: 1rem; border: none; outline: none; box-sizing: border-box;';
  wrapper.insertAdjacentElement('afterend', btn);
};

const isLastItem = () => current === myList.length;

const updateBtn = () => {
  const btn = document.querySelector('button');
  if (isLastItem()) {
    btn.textContent = `Done`;
    btn.style.backgroundColor = 'green';
    return;
  }
  btn.textContent = `Step ${current}`;
};

const setBgColor = () => {
  currentChild.style.backgroundColor = `hsl(105, 51%, ${80 / current + 20}%)`;
};

const removeBgColor = () => {
  currentChild.style.backgroundColor = '#fff';
};

const updateProgressBar = () => {
  current += 1;
  setBgColor();
  updateBtn();
};

const changeView = () => {
  wrapper.remove();
  addElement(body, addText(createElement('p'), 'Gratulerer!!'));
  const p = document.querySelector('p');
  p.style.cssText =
    'display: block; width: 500px; border: 1px solid #ccc; padding: 2rem; box-sizing: border-box; text-align: center; margin: 50px auto 0; font-weight: bold; transition: all 0.5s; transform: translateY(20px);';
};

const handleClick = (e) => {
  if (e.currentTarget.textContent === 'Done') {
    changeView();
    e.currentTarget.remove();
    return;
  }
  currentChild = wrapper.children[current];
  removeBgColor();
  updateProgressBar();
  setBgColor();
};

const addBtnListener = () => {
  const btn = document.querySelector('button');
  btn.addEventListener('click', handleClick);
};

try {
  resetWrapperStyle();
  createListElements();
  setStyle();
  createNextButton();
  addBtnListener();
} catch (error) {
  setError(error);
}
