/**
 *
 * Arrays
 *
 */

const baseArray = [1, 2, 50];
const firstValue = baseArray[0];
const arrLength = baseArray.length;
const lastValue = baseArray[baseArray.length - 1];
const anotherBaseArray = ['eple', 'bannan', 'drue', 'appelsin'];
const arrConcat = ['a', 'b', 'c'].concat([1, 2, 3]); // [a,b,c,1,2,3]
const every = [1, 30, 39, 29, 10, 13].every((item) => item < 15); // false
const some = [1, 30, 39, 29, 10, 13].some((item) => item < 15); // true
const forEach = baseArray.forEach((value, index) => {
  console.log(value, index);
});
const includes = [1, 2, 3].includes(2); // true
const filter = baseArray.filter((value) => value > 15); // [50];
const find = baseArray.find((value) => 2); // 1 (index)
const arrIndexOfNotFoundarrIndexOf = baseArray.indexOf(1); // 0
const arrIndexOfNotFound = baseArray.indexOf(3); // -1
const arrJoin = baseArray.join(','); // 1,2,50
const map = baseArray.map((value) => value * 2); // [2,4,100]
const pop = baseArray.pop(); // 50 (muterer baseArray da går på samme referanse)
const push = baseArray.push(50); // 3 returnerer lengden
const reduce = baseArray.reduce((sum, currentValue) => sum + currentValue, 0); // 53
const reverse = baseArray.reverse(); // [50,2,1] (muterer baseArray da går på samme referanse)
const shift = baseArray.shift(); // 50 (muterer baseArray da går på samme referanse)
const arrSlice = anotherBaseArray.slice(1, 3); // [bannan, drue]
const sort = anotherBaseArray.sort(); // [appelsin, bannan, drue, eple] (muterer anotherBaseArray da går på samme referanse)
const splice = anotherBaseArray.splice(1, 2, 'mango', 'pappaya'); // [appelsin, mango, pappaya, eple] (muterer anotherBaseArray da går på samme referanse)
const arrFrom = Array.from('word'); // [w,o,r,d]
const isArray = Array.isArray(arrFrom); // true
const typeOf = typeof arrFrom; // object

function removeItemById(id, array) {
  const personIndex = array.findIndex((person) => person.id === id);
  return [...array.slice(0, personIndex), ...array.slice(personIndex + 1)];
}

const newArray = [
  {
    id: 1,
    name: 'Fredrik',
  },
  {
    id: 2,
    name: 'Thomas',
  },
  {
    id: 3,
    name: 'Trine',
  },
];

const newArray2 = removeItemById(2, newArray);
console.log(newArray2);
