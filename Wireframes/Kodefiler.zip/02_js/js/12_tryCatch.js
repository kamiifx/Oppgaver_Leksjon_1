try {
  // Kode du vil kjøre
} catch (err) {
  // Håndtere feilen. Bør ikke ha generisk feilsjekk (sier veldig lite)
} finally {
  // Utføres uansett
}
