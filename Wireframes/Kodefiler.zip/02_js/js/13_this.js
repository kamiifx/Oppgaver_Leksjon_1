/**
 *
 *  this har et sett av regler du må kjenne til for å bruke det effektivt
 *
 */

// this => peker til global object i browseren
function foo() {
  console.log(this);
}

foo();

// this => object1 => bundet til objektet hvor funksjonen bor og dens sitt ytre scope
// Object {
//	x: “test”,
//	foo: function() {
//	console.log(this);
// }
// }
const object1 = {
  x: 'test',
  foo() {
    console.log(this); // hele objektet
    console.log(this.x); // test
  },
};

object1.foo();

/**
 *
 *  Ved bruk av call eller apply setter vi hva this skal være i funksjonen som kalles.
 *  Call og Apply virker på samme måte. Eneste forskjellen er at apply tar i mot en array med arg
 *  mens call tar i mot en variabler separert med komma
 *
 *
 * call og apply bruker mariuswallin objektet => this.getFullName() blir da maruswallin.getFullName()
 * argumentene blir da det som skal støtte parametrene i funksjonen
 */

const mariuswallin = {
  firstname: 'Marius',
  lastname: 'Wallin',
  getFullName() {
    const fullname = `${this.firstname} ${this.lastname}`;
    return fullname;
  },
};

const wallinLikes = function (food, subject) {
  console.log(
    `${this.getFullName()} likes ${food} and enjoy reading ${subject}`
  );
};

wallinLikes.call(mariuswallin, 'fish', 'blogs'); // Marius Wallin likes fish and enjoy reading blogs
wallinLikes.apply(mariuswallin, ['fish', 'blogs']); // Marius Wallin likes fish and enjoy reading blogs

/**
 * Bind kan brukes som call og apply ved å binde this til funksjonen. Forskjellen er at
 * bind ikke kjører funksjonen umiddelbart, men må kalles.
 *
 */

const obj = {
  a: 1,
  b: 2,
  c: 3,
};

const anotherObj = {
  a: 3,
  b: 4,
  c: 5,
};

function test() {
  console.log(this.a);
  console.log(this.b);
  console.log(this.c);
}

function callMeLater(cb) {
  setTimeout(() => {
    // kjører callbackfunksjonen som sendes inn og får referansen til this via bind
    cb();
  }, 3000);
}

callMeLater(test.bind(obj));
callMeLater(test.bind(anotherObj));

// Kan også brukes om du lager en generisk calc som skal brukes på ulike objekter

const baseCalc = {
  add() {
    console.log(this);
    return this.value1 + this.value2;
  },
};

const calcValue1 = {
  value1: 2,
  value2: 3,
};

const { add } = baseCalc;
console.log(add(calcValue1)); // NaN => kjenner ikke verdiene this ref til
console.log(add.bind(calcValue1)()); // 5 => kjenner verdiene

// Ved bruk av new nøkkelordet blir this selve objektet du lager

function Person() {
  this.name = 'Marius';
  this.age = 35;
  this.func = function () {
    console.log(`${this.name} is ${this.age} years old`);
  };
}

const marius = new Person();
marius.func(); // "Marius is 33 years old"

/**
 *
 * Arrow funksjoner har ingen binding til this. This vil være definert av den opprinnelige konteksten (window i browser)
 *
 */

const a = () => {
  console.log(this);
};

a(); // window object => {} i dette tilfellet da window er et tomt objekt

const obj2 = {
  doSomething() {
    setInterval(() => {
      console.log(this);
    }, 1000);
  },
};

// obj2.doSomething(); // obj2 objektet - som ved vanlig object1 uten arrow funksjon nevnt ovenfor

const obj3 = {
  doSomething: () => {
    console.log(this, 2);
  },
};

obj3.doSomething(); // window object

function Counter() {
  this.num = 0;
  this.timer = setInterval(() => {
    this.num++;
    console.log(this);
  }, 1000);
}

// let counter = new Counter(); // Counter object
