/* eslint-disable no-var */
/**
 *
 * Scope må man kjenne til av flere grunner
 * 1. Påvirker tilgjengeligheten til variablene dine
 * 2. Påvirker hvordan du "encapsulate" variabler i funksjoner (private variabler)
 * 3. Forhindrer feil som følge av at globale variabler blir reassigned ved en feil
 * 4. Bad praktisk å ha globale variabler
 *
 */

// Denne er tilgjengelig globalt og kan console.log(global) i browseren
const global = 'global';
let global2 = 'global2';

// Function scope
function funcScope() {
  const x = 'I am blocked scoped to the function';
  var q = 'I am function scoped';
  console.log(global2);
  global2 = 'Reassigned global2';
  console.log(global); // Er tilgjengelig da JS sjekker nærmeste scope først, deretter neste scope
  console.log(global2); // Sjekker først nærmeste scope
}

funcScope();

// console.log(x); // Error: Blocked scoped
// console.log(q); // Error: Function scoped

// Funksjoner blir scopa inne i andre funksjoner
function outerFunc() {
  function innerFunc() {
    console.log('inner');
  }
  innerFunc();
}

outerFunc();
// innerFunc(); // Error: ikke tilgjengelig

// Block scope
if (true) {
  const y = 'I am blocked scoped';
  var z = 'I am not blocked scoped';
}

// console.log(y); // Blocked scoped
console.log(z); // Ikke scoped da den bruker var

function loop() {
  const i = 0;
  for (let i = 2; i < 5; i++) {
    // Blocked scoped
    console.log(i);
  }
  console.log(`i: ${i}`); // i: 0 => i blir ikke overstyrt da den er blocked scoped inne i for loopen

  var j = 0;
  for (var j = 2; j < 5; j++) {
    // Ikke scoped
    console.log(j);
  }
  console.log(`j: ${j}`); // j: 5 => j blir overstyrt av j variabelen inne i for loopen
}

loop();
