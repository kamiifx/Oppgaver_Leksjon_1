/**
 *
 * Objects
 *
 */

const number = 2000;
const obj = {
  number,
  prop: 'obj.prop',
  anotherProp: 'obj.anotherProp',
  'with-dash': 'obj["with-dash"]',
  'with space': 'obj["with space"]',
  '1337': 'obj["1337"]',
  nestedObj: {
    prop1: true,
    prop2: false,
  },
  method() {
    return `${this.prop}`;
  },
};

const variabelToBeUsedToFindProp = 'anotherProp';
const value1 = obj[variabelToBeUsedToFindProp];
const value3 = obj.prop;
const value4 = obj['1337'];
const value5 = obj['with-dash'];
const value6 = obj['with space'];
const value7 = obj.nestedObj.prop1;
const value8 = obj.method();
obj.newProp = 'newProp';
const value9 = obj.newProp;
const value10 = delete obj.newProp;

// For å sende objects via request konverterer vi den til en string
const stringify = JSON.stringify(obj); // lage string
const parseJson = JSON.parse(stringify); // lage JSON

/**
 *
 * Noen innebygde funksjoner på Objekter
 *
 */

const baseObj = {
  name: 'Marius Wallin',
  age: 35,
  male: true,
};

const objValues = Object.values(baseObj); // [Marius Wallin, 35, true]
const objKeys = Object.keys(baseObj); // [name, age, male]
const objKeysValues = Object.entries(baseObj); // [['name', 'Marius Wallin'], ['age', 35], ['male', true]]
const freeze = Object.freeze(baseObj); // immutable object baseObj.name = "test"; går ikke
const seal = Object.seal(baseObj); // kan ikke legge til props men endre props som er der baseObj.name = "test"; går, men ikke baseObj.test = 'value';
const hasOwnProperty = baseObj.hasOwnProperty('name'); // true
const fromEntries = Object.fromEntries(objKeysValues); // blir som baseObj -> krever en liste med key, values
